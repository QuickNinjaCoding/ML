import pytesseract
import cv2
from PIL import Image
import pandas as pd

# Constants for the pdf
X_MARGIN1 = 1
X_MARGIN2 = 1
Y_MARGIN1 = 333
Y_MARGIN2 = 113
ADJUSTMENT_THRESHOLD = 10
SECTION_X_MAX = 200

def ocr_core(filename):
    """
    This function will handle the core OCR processing of images.
    """
    text = pytesseract.image_to_string(Image.open(filename))  # We'll use Pillow's Image class to open the image and pytesseract to detect the string in the image
    text1 = pytesseract.image_to_data(Image.open(filename))   
    return text1

def cropImage(mx1, my1, mx2, my2): 
    img = cv2.imread("2.jpg")
    crop_img = img[my1:-my2, mx1:-mx2]
    cv2.imwrite("2_cropped.jpg", crop_img)  

if __name__ == "__main__":
    # Crop the image
    cropImage(X_MARGIN1, Y_MARGIN1, X_MARGIN2, Y_MARGIN2)

    ocrData = ocr_core('2_cropped.jpg')
    with open('temp.csv', 'w', encoding="utf-8") as f:
        f.write(ocrData.replace("\t", ","))
    df = pd.read_csv("temp.csv")
    df = df[df.text != " "] 
    df.dropna(inplace=True)
    df.sort_values(by=['top'], inplace=True) 
    df.reset_index(inplace=True)
    top = -10000
    for i in range(len(df)):
        
        if df.loc[i, 'top']-top < ADJUSTMENT_THRESHOLD:
            # print(i , item['top'], top, item['text'] )
            df.loc[i, 'top'] = top
        top = df.loc[i, 'top']

    df.sort_values(by=['top', 'left'], inplace=True) 
    df.to_csv("temp2.csv", index=False) 
    # print(df)
    lines = []
    line = ""
    top = None
    
    for i, item in df.iterrows():
        if i==0:
            left = item['left']
        if(top==None or top==item['top']):
            line += " "
            line += item['text']
        else:
            lines.append([left, line])
            line = f"{item['text']}"
            left = item['left']
        
        top = item['top']
    
    indent = 0
    extract = []
    head = None
    subhead = None
    for i in range(len(lines)):
        print(lines[i][0])
        print(lines[i][1])
        if lines[i][0]<SECTION_X_MAX:
            # if the next text is indented
            if((lines[i+1][0] - lines[i][0])>12): 
                indent += 1
                if(indent==1):
                    head = lines[i][1]
                elif(indent==2):
                    subhead = lines[i][1]
                else:
                    # this is a data collection point
                    extract.append([head, subhead, lines[i][1]])
            elif((lines[i][0] - lines[i+1][0])>12): 



    print(extract)






